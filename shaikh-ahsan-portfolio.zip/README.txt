SHAIKH AHSAN — THUMBNAIL DESIGNER PORTFOLIO

Files:
- index.html
- images/ (your uploaded portrait and nine thumbnail designs)

To publish, upload index.html and the entire images folder to the root of your GitHub Pages repository.

Instagram URL is configured in the JavaScript. Pricing is intentionally not displayed; pricing is discussed after contact.
The before-and-after section stays hidden until actual before/after pairs are supplied.

To add thumbnails, edit the portfolioItems array in index.html and add an entry with title, category, and image path.
Categories: podcast, crypto, business, ai.
